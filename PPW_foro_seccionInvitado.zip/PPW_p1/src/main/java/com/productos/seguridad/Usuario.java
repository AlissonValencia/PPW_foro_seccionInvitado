package com.productos.seguridad;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import com.productos.datos.Conexion; // Importamos tu clase Conexion

public class Usuario { // Clase con 'U' mayúscula por convención

    private int idUsuario; // Renombrado de 'id' a 'idUsuario' para mayor claridad
    private String nombre;
    private String apellido; // Se mantiene, aunque no se usa en los métodos solicitados
    private String correo;   // Renombrado de 'email' a 'correo' para consistencia con DB
    private String clave;    // Renombrado de 'password' a 'clave' para consistencia con DB
    private String rol;      // Almacenará el nombre del perfil (admin, vendedor, cliente)
    private String cedula;   // Nuevo campo para la cédula
    private int estadoCivil; // Nuevo campo para el estado civil (ej. ID de una tabla de estados civiles)
    private String residencia; // Nuevo campo para la residencia

    private int idPerfil; // Campo interno para mapear el rol a la BD (id_per)

    private static final Logger logger = Logger.getLogger(Usuario.class.getName());

    public Usuario() {
    }

    // Constructor completo (ajustado a los nuevos campos)
    public Usuario(int idUsuario, String nombre, String apellido, String correo, String clave, String rol, String cedula, int estadoCivil, String residencia, int idPerfil) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.clave = clave;
        this.rol = rol;
        this.cedula = cedula;
        this.estadoCivil = estadoCivil;
        this.residencia = residencia;
        this.idPerfil = idPerfil;
    }

    // --- Getters y Setters ---
    public int getIdUsuario() { // Getter para idUsuario
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) { // Setter para idUsuario
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() { // Getter para correo (antes email)
        return correo;
    }

    public void setCorreo(String correo) { // Setter para correo (antes email)
        this.correo = correo;
    }

    public String getClave() { // Getter para clave (antes password)
        return clave;
    }

    public void setClave(String clave) { // Setter para clave (antes password)
        this.clave = clave;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getCedula() { // Getter para cédula
        return cedula;
    }

    public void setCedula(String cedula) { // Setter para cédula (Corregido el tipo de 'text' a 'String')
        this.cedula = cedula;
    }

    public int getEstadoCivil() { // Getter para estadoCivil
        return estadoCivil;
    }

    public void setEstadoCivil(int estadoCivil) { // Setter para estadoCivil
        this.estadoCivil = estadoCivil;
    }

    public String getResidencia() { // Getter para residencia
        return residencia;
    }

    public void setResidencia(String residencia) { // Setter para residencia
        this.residencia = residencia;
    }

    public int getIdPerfil() { // Getter para idPerfil
        return idPerfil;
    }

    public void setIdPerfil(int idPerfil) { // Setter para idPerfil
        this.idPerfil = idPerfil;
    }


    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario=" + idUsuario +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", correo='" + correo + '\'' +
                ", clave='" + clave + '\'' +
                ", rol='" + rol + '\'' +
                ", cedula='" + cedula + '\'' +
                ", estadoCivil=" + estadoCivil +
                ", residencia='" + residencia + '\'' +
                ", idPerfil=" + idPerfil +
                '}';
    }

    // --- Métodos de Lógica de Negocio ---

    // Método para hashear la contraseña (usando SHA-256)
    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            logger.log(Level.SEVERE, "Error al hashear la contraseña: " + e.getMessage(), e);
            throw new RuntimeException("Error al hashear la contraseña", e);
        }
    }

    // Este método verifica si la contraseña ingresada coincide con la hasheada almacenada
    public boolean checkPassword(String password) {
        // Hasheamos la contraseña de entrada y la comparamos con la contraseña hasheada de esta instancia
        return this.clave.equals(hashPassword(password)); // Usa 'clave' ahora
    }

    // Método auxiliar para obtener el próximo ID de usuario (PostgreSQL)
    private int obtenerProximoIdUsuario(Connection con) throws SQLException {
        int proximoId = 0;
        // Asegúrate de que la secuencia 'tb_usuario_id_us_seq' exista en tu base de datos
        String sql = "SELECT nextval('tb_usuario_id_us_seq')";
        try (PreparedStatement pstmt = con.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                proximoId = rs.getInt(1);
            }
        }
        return proximoId;
    }

    // Método para verificar si el usuario existe por correo
    private boolean existeUsuario(Connection con) throws SQLException {
        boolean existe = false;
        String sql = "SELECT COUNT(*) FROM tb_usuario WHERE correo_us = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, this.correo); // Usa el correo del objeto actual
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                existe = (rs.getInt(1) > 0);
            }
        }
        return existe;
    }

    // Método para insertar un nuevo cliente en la base de datos
    // Este método usa los atributos de la instancia actual de Usuario
    public String ingresarCliente() {
        String resultado = "";
        Conexion conexion = null;
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conexion = new Conexion();
            conn = conexion.getConexion();

            if (conn == null) {
                logger.log(Level.SEVERE, "ingresarCliente: No se pudo obtener conexión a la base de datos.");
                return "Error: No se pudo conectar a la base de datos.";
            }

            // Verificar si el usuario ya existe por correo
            if (existeUsuario(conn)) {
                return "Error: Ya existe un usuario con el correo: " + this.correo;
            }

            // Obtener el próximo ID de la secuencia
            this.idUsuario = obtenerProximoIdUsuario(conn);
            if (this.idUsuario == 0) { // Si nextval devuelve 0 o hay un problema
                return "Error: No se pudo obtener un ID de usuario válido.";
            }

            // Hashear la clave antes de insertarla
            String hashedClave = hashPassword(this.clave);

            // id_per para cliente (asumiendo 3 es el ID para cliente en tb_perfil)
            int idPerfilCliente = 3; // Ajusta esto si tu ID de cliente es diferente

            String sql = "INSERT INTO tb_usuario (id_us, id_per, id_est, nombre_us, cedula_us, correo_us, clave_us, residencia_us) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, this.idUsuario);
            pstmt.setInt(2, idPerfilCliente); // Perfil de cliente
            pstmt.setInt(3, this.estadoCivil);
            pstmt.setString(4, this.nombre);
            pstmt.setString(5, this.cedula);
            pstmt.setString(6, this.correo);
            pstmt.setString(7, hashedClave); // Guardar la clave hasheada
            pstmt.setString(8, this.residencia); // Residencia

            int filasInsertadas = pstmt.executeUpdate();
            if (filasInsertadas == 1) {
                resultado = "Usuario registrado con éxito.";
            } else {
                resultado = "Error al registrar el usuario.";
            }

        } catch (SQLException e) {
            resultado = "Error SQL al registrar usuario: " + e.getMessage();
            logger.log(Level.SEVERE, resultado, e);
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
                if (conexion != null) {
                    conexion.cerrarConexion();
                }
            } catch (SQLException e) {
                logger.log(Level.WARNING, "Error al cerrar recursos en ingresarCliente: " + e.getMessage(), e);
            }
        }
        return resultado;
    }


    // Método para verificar las credenciales de un usuario en la base de datos
    // Este método ahora crea su propia instancia de Conexion y la cierra
    public static Usuario verificarUsuario(String correo, String clave) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Usuario user = null;
        Conexion conexion = null;

        try {
            conexion = new Conexion(); // Crear una nueva instancia de Conexion
            conn = conexion.getConexion(); // Obtener la conexión

            if (conn == null) {
                logger.log(Level.SEVERE, "verificarUsuario: No se pudo obtener conexión a la base de datos.");
                return null;
            }

            // Consulta para obtener el usuario por correo
            String sql = "SELECT id_us, nombre_us, clave_us, id_per, correo_us FROM tb_usuario WHERE correo_us = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, correo);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String storedHashedClave = rs.getString("clave_us"); // Obtiene la clave HASHED de la base de datos.
                // Comparamos el hash de la clave ingresada con el hash almacenado
                if (hashPassword(clave).equals(storedHashedClave)) {
                    user = new Usuario();
                    user.setIdUsuario(rs.getInt("id_us"));
                    user.setNombre(rs.getString("nombre_us"));
                    user.setCorreo(rs.getString("correo_us"));
                    user.setClave(storedHashedClave); // Guardar el hash de la clave obtenida de la BD
                    user.setIdPerfil(rs.getInt("id_per")); // Guardar el ID del perfil
                    user.setRol(obtenerNombrePerfil(rs.getInt("id_per"), conn)); // Obtener el nombre del rol
                } else {
                    logger.log(Level.WARNING, "Intento de inicio de sesión fallido para " + correo + ": Contraseña incorrecta.");
                }
            } else {
                logger.log(Level.WARNING, "Intento de inicio de sesión fallido: Usuario " + correo + " no encontrado.");
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error SQL al verificar el usuario: " + e.getMessage(), e);
        } finally {
            // Asegurarse de cerrar todos los recursos
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close(); // Cerrar la conexión obtenida aquí
                }
                if (conexion != null) {
                    conexion.cerrarConexion();
                }
            } catch (SQLException e) {
                logger.log(Level.WARNING, "Error al cerrar recursos en verificarUsuario: " + e.getMessage(), e);
            }
        }
        return user;
    }

    // Método auxiliar para obtener el nombre del perfil (rol)
    private static String obtenerNombrePerfil(int idPerfil, Connection con) throws SQLException {
        String nombrePerfil = "";
        String sql = "SELECT nombre_per FROM tb_perfil WHERE id_per = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, idPerfil);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                nombrePerfil = rs.getString("nombre_per");
            }
        }
        return nombrePerfil;
    }

    // Método para cambiar la contraseña de un usuario
    // Este método es estático y recibe el ID del usuario y la nueva clave.
    public static String cambiarClave(int idUsuario, String nuevaClave) { // Cambiado el tipo de retorno a String
        String resultado = ""; // Variable para almacenar el resultado
        Connection conn = null;
        PreparedStatement pstmt = null;
        Conexion conexion = null;

        try {
            conexion = new Conexion();
            conn = conexion.getConexion();

            if (conn == null) {
                logger.log(Level.SEVERE, "cambiarClave: No se pudo obtener conexión a la base de datos.");
                return "Error: No se pudo conectar a la base de datos.";
            }

            // Hashear la nueva contraseña antes de actualizarla
            String hashedClave = hashPassword(nuevaClave);
            String sql = "UPDATE tb_usuario SET clave_us = ? WHERE id_us = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, hashedClave);
            pstmt.setInt(2, idUsuario);
            int filasActualizadas = pstmt.executeUpdate();
            if (filasActualizadas > 0) {
                resultado = "Contraseña cambiada con éxito.";
            } else {
                resultado = "No se pudo cambiar la contraseña.";
            }
        } catch (SQLException e) {
            resultado = "Error SQL al cambiar la clave para usuario ID " + idUsuario + ": " + e.getMessage();
            logger.log(Level.SEVERE, resultado, e);
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
                if (conexion != null) {
                    conexion.cerrarConexion();
                }
            } catch (SQLException e) {
                logger.log(Level.WARNING, "Error al cerrar recursos en cambiarClave: " + e.getMessage(), e);
            }
        }
        return resultado; // Retornar el resultado como String
    }
}
