package com.productos.negocio;

import java.sql.*;
import com.productos.datos.Conexion;
import java.util.ArrayList; // Importar ArrayList
import java.util.List;     // Importar List

public class Producto { // CORREGIDO: Clase con 'P' mayúscula

    // Nuevos atributos para almacenar los datos del producto
    private int idProducto;
    private String nombreProducto;
    private double precioProducto;
    private boolean enOferta;
    private double precioOferta; // Nuevo atributo para el precio de oferta
    private int cantidadProducto; // Agregado: Atributo para la cantidad del producto

    // Constructor vacío
    public Producto() {
    }

    // Getters y setters
    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }

    public boolean isEnOferta() {
        return enOferta;
    }

    public void setEnOferta(boolean enOferta) {
        this.enOferta = enOferta;
    }

    public double getPrecioOferta() {
        return precioOferta;
    }

    public void setPrecioOferta(double precioOferta) {
        this.precioOferta = precioOferta;
    }

    // Agregado: Getter para cantidadProducto
    public int getCantidadProducto() {
        return cantidadProducto;
    }

    // Agregado: Setter para cantidadProducto
    public void setCantidadProducto(int cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }


    // Método para consultar todos los productos y devolverlos en una tabla HTML
    public String consultarTodo() {
        String sql = "SELECT id_pr, nombre_pr, cantidad_pr, precio_pr FROM tb_producto ORDER BY id_pr";
        Conexion con = null; // Declarar la conexión fuera del try para el finally
        ResultSet rs = null;
        String tabla = "<table border='2'><tr><th>ID</th><th>Producto</th><th>Cantidad</th><th>Precio</th></tr>";
        try {
            con = new Conexion(); // Crear la instancia de Conexion
            rs = con.Consulta(sql); // Usar el método Consulta de la clase Conexion
            if (rs != null) {
                while (rs.next()) {
                    // Crear un objeto Producto para cada fila (opcional, pero buena práctica)
                    Producto producto = new Producto();
                    producto.setIdProducto(rs.getInt("id_pr"));
                    producto.setNombreProducto(rs.getString("nombre_pr"));
                    producto.setCantidadProducto(rs.getInt("cantidad_pr")); // Ahora este método existe
                    producto.setPrecioProducto(rs.getDouble("precio_pr"));

                    tabla += "<tr><td>" + producto.getIdProducto() + "</td>"
                            + "<td>" + producto.getNombreProducto() + "</td>"
                            + "<td>" + producto.getCantidadProducto() + "</td>" // Ahora este método existe
                            + "<td>" + String.format("%.2f", producto.getPrecioProducto()) + "</td></tr>"; // Formatear precio
                }
            } else {
                tabla += "<tr><td colspan='4'>No se pudo conectar a la base de datos o no hay resultados.</td></tr>";
            }
        } catch (SQLException e) {
            tabla += "<tr><td colspan='4'>Error al consultar productos: " + e.getMessage() + "</td></tr>";
            System.err.println("Error en consultarTodo(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Cerrar recursos en un bloque finally
            try {
                if (rs != null) {
                    rs.close();
                }
                // La conexión debe cerrarse desde la instancia de Conexion
                if (con != null) {
                    con.cerrarConexion();
                }
            } catch (SQLException ex) {
                System.err.println("Error al cerrar recursos en consultarTodo(): " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        tabla += "</table>";
        return tabla;
    }

    // Método para obtener productos en oferta (existente en tu código)
    public static List<Producto> obtenerProductosEnOferta() { // Corregido: List<Producto>
        List<Producto> productosEnOferta = new ArrayList<>();
        Conexion conexion = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conexion = new Conexion();
            con = conexion.getConexion();
            if (con != null) {
                String sql = "SELECT id_pr, nombre_pr, precio_pr, en_oferta, precio_oferta FROM tb_producto WHERE en_oferta = true";
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    Producto prod = new Producto(); // Corregido: Producto
                    prod.setIdProducto(rs.getInt("id_pr"));
                    prod.setNombreProducto(rs.getString("nombre_pr"));
                    prod.setPrecioProducto(rs.getDouble("precio_pr"));
                    prod.setEnOferta(rs.getBoolean("en_oferta"));
                    prod.setPrecioOferta(rs.getDouble("precio_oferta"));
                    productosEnOferta.add(prod);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener productos en oferta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conexion != null) conexion.cerrarConexion(); // Cerrar la conexión
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos en obtenerProductosEnOferta: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return productosEnOferta;
    }

    // Método para actualizar el estado de oferta y precio de oferta de un producto (existente en tu código)
    public static String actualizarOfertaProducto(int idProducto, boolean enOferta, double precioOferta) {
        Conexion conexion = null;
        Connection con = null;
        PreparedStatement ps = null;
        String resultado = "";
        try {
            conexion = new Conexion();
            con = conexion.getConexion();
            if (con != null) {
                String sql = "UPDATE tb_producto SET en_oferta = ?, precio_oferta = ? WHERE id_pr = ?";
                ps = con.prepareStatement(sql);
                ps.setBoolean(1, enOferta);
                ps.setDouble(2, precioOferta);
                ps.setInt(3, idProducto);
                int filasActualizadas = ps.executeUpdate();
                if (filasActualizadas > 0) {
                    resultado = "Producto actualizado correctamente.";
                } else {
                    resultado = "No se pudo actualizar el producto.";
                }
            } else {
                resultado = "Error: No hay conexión a la base de datos.";
            }
        } catch (SQLException e) {
            resultado = "Error al actualizar el producto: " + e.getMessage();
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (conexion != null) conexion.cerrarConexion();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos en actualizarOfertaProducto: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return resultado;
    }

    // Nuevo método para buscar productos por categoría (existente en tu código)
    public List<Producto> buscarProductoCategoria(int idCategoria) { // Corregido: List<Producto>
        List<Producto> productos = new ArrayList<>();
        Conexion conexion = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conexion = new Conexion();
            con = conexion.getConexion();
            if (con != null) {
                String sql = "SELECT id_pr, nombre_pr, precio_pr FROM tb_producto WHERE id_cat = ?";
                ps = con.prepareStatement(sql);
                ps.setInt(1, idCategoria);
                rs = ps.executeQuery();

                while (rs.next()) {
                    Producto prod = new Producto(); // Corregido: Producto
                    prod.setIdProducto(rs.getInt("id_pr"));
                    prod.setNombreProducto(rs.getString("nombre_pr"));
                    prod.setPrecioProducto(rs.getDouble("precio_pr"));
                    productos.add(prod);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar productos por categoría: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conexion != null) conexion.cerrarConexion();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos en buscarProductoCategoria: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return productos;
    }
}
