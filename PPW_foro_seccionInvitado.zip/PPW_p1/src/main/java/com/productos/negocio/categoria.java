package com.productos.negocio;

import java.sql.*;

public class categoria {

    public String mostrarCategoria() {
        String combo = "<select name='cmbCategoria'>";
        String sql = "SELECT * FROM tb_categoria";

        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("org.postgresql.Driver");  // o tu driver
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bd_productos", "postgres", "1234");
            stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                combo += "<option value='" + rs.getInt(1) + "'>" + rs.getString(2) + "</option>";
            }
        } catch (Exception e) {
            combo += "<option>Error: " + e.getMessage() + "</option>";
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }

        combo += "</select>";
        return combo;
    }
}
