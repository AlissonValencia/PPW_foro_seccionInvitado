package com.productos.datos;

import java.sql.*;

public class Conexion {
    private Statement St;
    private String driver;
    private String user;
    private String pwd;
    private String cadena;
    private Connection con;

    // Constructor
    public Conexion() {
        this.driver = "org.postgresql.Driver";
        this.user = "postgres";
        this.pwd = "1234";
        this.cadena = "jdbc:postgresql://localhost:5432/bd_productos";
        this.con = this.crearConexion();
    }

    // Getters
    String getDriver() {
        return this.driver;
    }

    String getUser() {
        return this.user;
    }

    String getPwd() {
        return this.pwd;
    }

    String getCadena() {
        return this.cadena;
    }

    public Connection getConexion() {
        return this.con;
    }

    // Crear conexión
    Connection crearConexion() {
        try {
            Class.forName(getDriver());
            Connection con = DriverManager.getConnection(getCadena(), getUser(), getPwd());
            System.out.println("Conexión creada con éxito.");
            return con;
        } catch (Exception e) {
            System.out.println("Error al crear conexión: " + e.getMessage());
            return null;
        }
    }

    // Método para probar la conexión
    public void probarConexion() {
        try {
            if (con != null && !con.isClosed()) {
                System.out.println("Conexión a la base de datos exitosa.");
            } else {
                System.out.println("No se pudo conectar a la base de datos.");
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar la conexión: " + e.getMessage());
        }
    }

    // Método para ejecutar instrucciones SQL (insert, update, delete)
    public String Ejecutar(String sql) {
        String resultado = "";
        try {
            St = getConexion().createStatement();
            St.execute(sql);
            resultado = "Datos insertados o ejecutados con éxito.";
        } catch (Exception ex) {
            resultado = "Error: " + ex.getMessage();
        } finally {
            // Added finally block to close the statement
            if (St != null) {
                try {
                    St.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar el Statement: " + e.getMessage());
                    e.printStackTrace(); // It's good practice to log the error
                }
            }
        }
        return resultado;
    }

    // Método para hacer consultas SQL (select)
    public ResultSet Consulta(String sql) {
        ResultSet reg = null;
        try {
            St = getConexion().createStatement();
            reg = St.executeQuery(sql);
        } catch (Exception ee) {
            System.out.println("Error en consulta: " + ee.getMessage());
        } finally {
            //Note: The ResultSet and Statement should be closed.
            //However,  you are returning the ResultSet, so you cannot close it here.
            //The calling method is responsible for closing the ResultSet and Statement.
        }
        return reg;
    }

    // Método para probar consulta simple
    public void probarConsulta() {
        try {
            String sql = "SELECT 1";
            ResultSet rs = Consulta(sql);
            if (rs != null && rs.next()) {
                System.out.println("Consulta exitosa, resultado: " + rs.getInt(1));
            } else {
                System.out.println("Consulta no devolvió resultados.");
            }
             if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar ResultSet: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        }
    }

    // Programa principal para probar la conexión
    public static void main(String[] args) {
        Conexion c = new Conexion();
        c.probarConexion();
        c.probarConsulta();
    }

    // Método para obtener un PreparedStatement
    public PreparedStatement getPreparedStatement(String sql) throws SQLException {
        return con.prepareStatement(sql);
    }

     public void cerrarConexion() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Conexión cerrada correctamente.");
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
            e.printStackTrace();
        }
    }
}